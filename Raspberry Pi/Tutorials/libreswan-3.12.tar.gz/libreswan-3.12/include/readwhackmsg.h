extern void readwhackmsg(char *infile);
