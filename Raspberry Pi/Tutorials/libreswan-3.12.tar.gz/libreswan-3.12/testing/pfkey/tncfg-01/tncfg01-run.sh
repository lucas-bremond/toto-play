./tncfg01 --create mast1

