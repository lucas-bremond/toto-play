bool nat_traversal_support_non_ike = FALSE;
bool nat_traversal_support_port_floating = FALSE;
void nat_traversal_change_port_lookup(struct msg_digest *md, struct state *st)
{
}
void nat_traversal_ka_event(void)
{
}

