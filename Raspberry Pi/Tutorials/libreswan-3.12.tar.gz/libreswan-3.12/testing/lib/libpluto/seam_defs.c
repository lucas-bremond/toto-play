const char *check_expiry(time_t expiration_date, int warning_interval,
			bool strict)
{
	return "ok";
}
