/* efence defines */
extern int EF_DISABLE_BANNER;
extern int EF_ALIGNMENT;
extern int EF_PROTECT_BELOW;
extern int EF_PROTECT_FREE;
extern int EF_ALLOW_MALLOC_0;
/*
 * Paul: I cannot find this in efence
 * extern int EF_FREE_WIPES;
 */
int EF_FREE_WIPES = 0;
