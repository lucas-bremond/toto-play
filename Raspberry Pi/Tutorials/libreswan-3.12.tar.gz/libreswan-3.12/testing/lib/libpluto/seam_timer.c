/* timer.c SEAM */
void timer_list(void)
{
}

void event_schedule(enum event_type type, time_t tm, struct state *st)
{
}
void attributed_delete_dpd_event(struct state *st, const char *file, int lineno)
{
}
void delete_event(struct state *st)
{
}

