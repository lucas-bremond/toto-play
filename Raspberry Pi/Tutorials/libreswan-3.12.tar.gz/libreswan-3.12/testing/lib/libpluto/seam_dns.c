void gw_delref(struct gw_info **gwp)
{
}

void gw_addref(struct gw_info *gw)
{
}

