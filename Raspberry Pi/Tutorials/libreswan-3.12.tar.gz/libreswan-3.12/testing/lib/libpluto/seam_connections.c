bool in_pending_use(struct connection *c)
{
	DBG_log("called in_pending_use, returned FALSE");
	return FALSE;
}
