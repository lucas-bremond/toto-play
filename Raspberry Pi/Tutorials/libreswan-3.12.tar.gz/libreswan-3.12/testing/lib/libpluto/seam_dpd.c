void dpd_event(struct state *st)
{
}
void dpd_timeout(struct state *st)
{
}

