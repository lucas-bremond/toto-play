export TZ=UTC

../parentI3psk ../lib-parentI1psk/ikev2.record westnet--eastnet-ikev2 ../lib-parentR2psk/parentR2psk.pcap 2>&1 | sed -f sanity.sed


