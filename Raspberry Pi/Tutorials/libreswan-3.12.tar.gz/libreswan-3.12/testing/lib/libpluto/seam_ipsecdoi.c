void send_delete(struct state *st)
{
}

void ipsecdoi_replace(struct state *st, lset_t add, lset_t del,
		      unsigned long try)
{
}

