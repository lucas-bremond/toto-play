extern const struct kernel_ops noklips_kernel_ops;
const struct kernel_ops *kernel_ops = &noklips_kernel_ops;

