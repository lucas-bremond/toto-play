void terminate_connection(const char *nm)
{
}
