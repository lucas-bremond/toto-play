/* xauth.c SEAM */
oakley_auth_t xauth_calcbaseauth(oakley_auth_t baseauth)
{
	return baseauth;
}

