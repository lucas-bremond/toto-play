set +o emacs

: ==== start ====

ipsec barf | grep '^\+ _____________________'

: ==== end ====
