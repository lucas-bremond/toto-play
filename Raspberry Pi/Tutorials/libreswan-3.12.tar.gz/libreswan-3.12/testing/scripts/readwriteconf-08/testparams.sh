REF_CONSOLE_OUTPUT=ipsec-flat.conf
REF_CONSOLE_FIXUPS="confwritesanity.sed"
TESTSCRIPT=runit.sh
PROGRAMS=readwriteconf
TEST_TYPE=unittest
TESTNAME=readwriteconf-08


