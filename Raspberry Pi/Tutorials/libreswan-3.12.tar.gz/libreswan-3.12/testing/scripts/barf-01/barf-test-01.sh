set +o emacs

: ==== start ====

ipsec barf >/dev/null

: ==== end ====

