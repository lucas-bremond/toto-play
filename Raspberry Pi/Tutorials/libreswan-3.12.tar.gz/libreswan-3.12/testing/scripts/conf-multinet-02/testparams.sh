REF_CONSOLE_OUTPUT=ipsec-flat.conf
REF_CONSOLE_FIXUPS="confwritesanity.sed"
TESTSCRIPT=runit.sh
TEST_TYPE=unittest
TESTNAME=conf-multinet-02

