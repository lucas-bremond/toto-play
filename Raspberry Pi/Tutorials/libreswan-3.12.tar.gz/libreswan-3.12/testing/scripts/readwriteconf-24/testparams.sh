REF_CONSOLE_OUTPUT=configsetup-flat.conf
REF_CONSOLE_FIXUPS="confwritesanity.sed"
TESTSCRIPT=runit.sh
PROGRAMS=readwriteconf
TEST_TYPE=unittest
TESTNAME=readwriteconf-24

