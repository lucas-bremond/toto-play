REF_CONSOLE_OUTPUT=mrcharlie-flat.conf
REF_CONSOLE_FIXUPS="confwritesanity.sed"
TESTSCRIPT=runit.sh
PROGRAMS=readwriteconf
TEST_TYPE=unittest
TESTNAME=readwriteconf-18

